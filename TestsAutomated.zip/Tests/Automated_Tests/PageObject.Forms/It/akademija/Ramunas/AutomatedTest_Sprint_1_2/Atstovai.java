package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Atstovai extends PageObject {

	public Atstovai(WebDriver webDriver, String baseUrl) {
		super(webDriver, baseUrl);

	}

	// =================================================
	@FindBy(css = ".modal-content")
	@CacheLookup
	private WebElement confirmWind;
	@FindBy(xpath = "//button[contains(text(), 'Patvirtinti')]")
	@CacheLookup
	private WebElement confDel;
	@FindBy(xpath = "//button[contains(text(), 'Redaguoti')]")
	@CacheLookup
	private WebElement buttonEdit;	
	// =================================================
	
	// ===============Fields============================
	@FindBy(xpath = "//form/div[1]/div/input")
	@CacheLookup
	private WebElement fieldName;
	@FindBy(xpath = "//form/div[2]/div/input")
	@CacheLookup
	private WebElement fieldSure;
	// =================================================
	private FileReader fileReader = new FileReader();
	//=================================================
	public void assertEditRepr(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		String repName = words[5];
		String repSur = words[6];
		pressEditRep(repName, repSur);
		setTextFieldValueWithClear(fieldName, repName+repName);
		setTextFieldValueWithClear(fieldSure, repSur+repSur);
		buttonEdit.click();
		checkIsLoaded();
		Assert.assertFalse(elementVisibilityInTable(repName),"Didnt change but created new");
		Assert.assertTrue(elementVisibilityInTable(repName+repName), "Didnt change");

	}

	public void assertDelRepr(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		String repName = words[5];
		String repSur = words[6];
		pressDeleteRep(repName, repSur);
		waitForElementToBeInDOM(confirmWind);
		confDel.click();
		checkIsLoaded();
		webDriver.navigate().refresh();
		Assert.assertFalse(elementVisibilityInTable(repName));
		
	}
	private void pressEditRep(String repName, String repSur) {
		WebElement buttonEdit = webDriver.findElement(By.xpath("//td[contains(text(),'" + repName
				+ "')]/../td[contains(text(),'" + repSur + "')]/../td[5]/button[1]"));
		buttonEdit.click();
	}

	private void pressDeleteRep(String repName, String repSur) {
		WebElement buttondDel = webDriver.findElement(By.xpath("//td[contains(text(),'" + repName
				+ "')]/../td[contains(text(),'" + repSur + "')]/../td[5]/button[2]"));
		buttondDel.click();
	}
	private boolean elementVisibilityInTable(String name) {

		return isElementPresent(By.xpath("//*[text()='" + name + "']"));
	}
}
