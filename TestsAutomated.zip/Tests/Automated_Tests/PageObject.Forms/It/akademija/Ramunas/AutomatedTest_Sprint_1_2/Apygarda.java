package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Apygarda extends PageObject {
	private String districtName = "";
	// ============Buttons====================
	@FindBy(xpath = "//button[contains(text(), 'Registruoti')]")
	@CacheLookup
	private WebElement buttonRegister;
	@FindBy(xpath = "//button[contains(text(), 'Redaguoti')]")
	@CacheLookup
	private WebElement buttonEdit;
	@FindBy(xpath = "//button[contains(text(), 'Patvirtinti')]")
	@CacheLookup
	private WebElement confDel;
	@FindBy(xpath = "//input[@type='file']")
	@CacheLookup
	private WebElement buttonAddList;

	@FindBy(xpath = "//button[contains(text(), 'Atšaukti')]")
	@CacheLookup
	private WebElement buttonCancel;

	@FindBy(xpath = "//a[contains(text(), 'Pridėti apygardą')]")
	@CacheLookup
	private WebElement buttonAdd;
	@FindBy(xpath = "//button[contains(text(), 'Ištrinti kandidatus')]")
	@CacheLookup
	private WebElement delList;
	// ============================================
	// ==============Fields========================
	@FindBy(id = "pavadinimas")
	@CacheLookup
	private WebElement fieldName;
	@FindBy(css = ".modal-content")
	@CacheLookup
	private WebElement confirmWind;
	// ============================================
	private FileReader fileReader = new FileReader();

	// =================================================
	public Apygarda(WebDriver webDriver, String baseUrl) {
		super(webDriver, baseUrl);
	}

	public void assertInputDistrict(String fileNameForTest, String fileNameCsv) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertRegisterDistrict");
		String[] words = fileReader.get1LinesWords(fileNameForTest);
		districtName = words[0];
		buttonAdd.click();
		setTextFieldValue(fieldName, districtName);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		Assert.assertTrue(elementVisibility(districtName), "Didnt register district");
		if (elementVisibility(districtName)) {
			logger.log(LogStatus.PASS, "District registred fine");
		} else {
			logger.log(LogStatus.FAIL, "Didnt register district");
		}
		logger.endTest();
	}

	public void assertCandidateList(String fileNameForTest, String fileNameCsv) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertSoloMandateCandidateListContent");
		String[] words = fileReader.get1LinesWords(fileNameForTest);
		districtName = words[0];
		buttonAdd.click();
		setTextFieldValue(fieldName, districtName);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		checkIsLoaded();
		pressCandidateList(districtName);
		checkIsLoaded();
		boolean isOk = assertCandidateContent(fileNameCsv);
		Assert.assertTrue(isOk, "Neveikia gerai");
		if (isOk) {
			logger.log(LogStatus.PASS, "Solo Mandate Candidate List Content displayed correctly");
		} else {
			logger.log(LogStatus.FAIL, "Solo Mandate Candidate List Content displayed wrong");
		}
		logger.endTest();
	}

	public void assertVicinityList(String fileNameForTest) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertVicinityListContent");
		boolean testStatus = true;
		Map<String, List<String>> dist_vicin_map = getMapOfDistircitAndVicinities(fileNameForTest);
		Iterator it = dist_vicin_map.entrySet().iterator();
		for (Map.Entry<String, List<String>> entry : dist_vicin_map.entrySet()) {
			String district = entry.getKey();
			List<String> vicinities = entry.getValue();
			pressVicinityList(district);
			for (String vicinity : vicinities) {
				checkIsLoaded();
				if (!elementVisibility(vicinity)) {
					testStatus = false;
					break;
				}
			}
			webDriver.navigate().back();
		}
		Assert.assertTrue(testStatus, "Blogai ima duomenis is duomenu bazes");
		if (testStatus) {
			logger.log(LogStatus.PASS, "Vicinity List Content shows correctly");
		} else {
			logger.log(LogStatus.FAIL, "Vicinity List Content shows wrong");
		}
		logger.endTest();
	}

	public void assertDeleteDistrict(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertDeleteDistrict");
		List<String> fileData = fileReader.getTestData(fileName);
		boolean testStatue = true;
		districtName = fileData.get(0);
		pressDeleteDistrict(districtName);
		waitForElementToBeInDOM(confirmWind);
		confDel.click();
		checkIsLoaded();
		waitForElementToBeInDOM(buttonAdd);
		webDriver.navigate().refresh();
		checkIsLoaded();
		Assert.assertFalse(elementVisibility(districtName), "Didnt delete district");
		if (!elementVisibility(districtName)) {
			logger.log(LogStatus.PASS, "Delete district works");
		} else {
			logger.log(LogStatus.FAIL, "Delete district not works");
		}
		logger.endTest();
	}

	public void assertEdit(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertEditDistrict");
		String[] words = fileReader.get1LinesWords(fileName);
		districtName = words[0];
		pressEditDistrict(districtName);
		setTextFieldValueWithClear(fieldName, "Meksika");
		checkIsLoaded();
		buttonEdit.click();
		Assert.assertFalse(elementVisibility(districtName), "Didnt change district1");
		Assert.assertTrue(elementVisibility("Meksika"), "Didnt change district2");
		if (!elementVisibility(districtName) && elementVisibility("Meksika")) {
			logger.log(LogStatus.PASS, "Vicinity editing works");
		} else {
			logger.log(LogStatus.FAIL, "Vicinity editing not works");
		}
		logger.endTest();
	}

	public void assertVicinityListButton(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertVicinityListButton");
		String[] words = fileReader.get1LinesWords(fileName);
		districtName = words[0];
		pressVicinityList(districtName);
		Assert.assertTrue(isElementPresent(By.xpath("//*[contains(text(),'Apylinkių sąrašas')]")),
				"Didnt go to page vicinity list");
		if (isElementPresent(By.xpath("//*[contains(text(),'Apylinkių sąrašas')]"))) {
			logger.log(LogStatus.PASS, "Vicinity list button works");
		} else {
			logger.log(LogStatus.FAIL, "Vicinity list button not works");
		}
		logger.endTest();
	}

	public void assertCancel(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertCancel");
		String[] words = fileReader.get1LinesWords(fileName);
		districtName = words[0];
		pressEditDistrict(districtName);
		setTextFieldValueWithClear(fieldName, "Meksika");
		buttonCancel.click();
		checkIsLoaded();
		Assert.assertFalse(elementVisibility("Meksika"), "Didnt cancel, but created new");
		Assert.assertTrue(elementVisibility(districtName), "Didnt change district1");
		if (!elementVisibility("Meksika") && elementVisibility(districtName)) {
			logger.log(LogStatus.PASS, "Cancel button works");
		} else {
			logger.log(LogStatus.PASS, "Cancel button not works");
		}
		logger.endTest();
	}

	public void assertCancelConfirm(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertCancelConfirmDistrict");
		String[] words = fileReader.get1LinesWords(fileName);
		districtName = words[0];
		pressDeleteDistrict(districtName);
		waitForElementToBeInDOM(confirmWind);
		buttonCancel.click();
		checkIsLoaded();
		Assert.assertTrue(elementVisibility(districtName), "Didnt change district1");
		if (elementVisibility(districtName)) {
			logger.log(LogStatus.PASS, "Cancel Confirm District works");
		} else {
			logger.log(LogStatus.FAIL, "Cancel Confirm District works");
		}
		logger.endTest();
	}

	public void assertCandidateListButton(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertCandidateListButton");
		String[] words = fileReader.get1LinesWords(fileName);
		districtName = words[0];
		pressCandidateList(districtName);
		Assert.assertTrue(isElementPresent(By.xpath("//*[contains(text(),'Kandidatų sąrašas')]")),
				"Didnt go to page candidate list");
		if (isElementPresent(By.xpath("//*[contains(text(),'Kandidatų sąrašas')]"))) {
			logger.log(LogStatus.PASS, "Candidate List Button works");
		} else {
			logger.log(LogStatus.FAIL, "Candidate List Button not works");
		}
		logger.endTest();
	}

	public void assertNameValidation(String fileName) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertDistrictNameValidation");
		List<String> fileLines = fileReader.getTestData(fileName);
		boolean passOrFail = true;
		for (String district : fileLines) {
			RegisterDistrict(district);
			checkIsLoaded();
			if (elementVisibility(district)) {
				passOrFail = false;
				break;
			}
		}
		if (passOrFail) {
			logger.log(LogStatus.PASS, "Validation works");
		} else {
			logger.log(LogStatus.FAIL, "Bad words were allowed to register");
		}
		Assert.assertTrue(passOrFail, "Uzregistruotas neleistinas zodis: ");
		logger.endTest();

	}

	// Kazkodel reikia perkurti webelementus, kinda sucks :9
	private void RegisterDistrict(String district) {
		waitForElementToBeInDOM(buttonAdd);
		buttonAdd.click();
		checkIsLoaded();
		WebElement fName = webDriver.findElement(By.xpath("//*[@id='pavadinimas']"));
		WebElement bRegister = webDriver.findElement(By.xpath("//button[contains(text(), 'Registruoti')]"));
		// waitUntilElementToBeClickable(By.xpath("//*[@id='pavadinimas']"));
		// setTextFieldValue(fieldName, district);
		setTextFieldValueWithClear(fName,district );
		//fName.sendKeys(district);
		bRegister.click();
		checkIsLoaded();
	}

	public void assertDistrictCandidateDeletionButton(String fileNameForTest, String fileNameCsv) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertDistrictCandidateDeletionButton");
		String[] words = fileReader.get1LinesWords(fileNameForTest);
		districtName = words[0];
		buttonAdd.click();
		setTextFieldValue(fieldName, districtName);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		checkIsLoaded();
		pressCandidateList(districtName);
		checkIsLoaded();
		deleteCandidateManualy(fileNameCsv);
		webDriver.navigate().refresh();
		boolean testStatus = assertCandidateListDeletion(fileNameCsv);
		Assert.assertTrue(testStatus, "Nepasalintas kandidatas");
		if (testStatus) {
			logger.log(LogStatus.PASS, "District Candidate Deletion Button works");
		} else {
			logger.log(LogStatus.FAIL, "District Candidate Deletion Button not works");
		}
		logger.endTest();
	}

	public void assertDistrictListDelete(String fileNameForTest, String fileNameCsv) throws IOException {
		logger.init(Constants.saveResults, false);
		logger.startTest("assertDistrictCandidatesDeletion");
		String[] words = fileReader.get1LinesWords(fileNameForTest);
		districtName = words[0];
		buttonAdd.click();
		setTextFieldValue(fieldName, districtName);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		checkIsLoaded();
		pressEditDistrict(districtName);
		delList.click();
		buttonEdit.click();
		pressCandidateList(districtName);
		checkIsLoaded();
		Assert.assertFalse(isElementPresent(By.xpath("//tbody/tr[1]")), "Sarasas nepasalintas");
		if (!isElementPresent(By.xpath("//tbody/tr[1]"))) {
			logger.log(LogStatus.PASS, "District Candidates Deletion works");
		} else {
			logger.log(LogStatus.FAIL, "District Candidates Deletion not works");
		}
		logger.endTest();
		// assertCandidateListDeletion(fileNameCsv);
	}

	private boolean assertCandidateListDeletion(String fileNameCsv) throws IOException {
		List<String> fileData = fileReader.getTestData(fileNameCsv);
		for (int i = 1; i <= fileData.size(); i++) {
			String[] line = fileData.get(i - 1).split(",");
			String name = line[1].replace("\'", "").trim();
			String sure = line[2].replace("\'", "").trim();
			String dateBirth = line[3].trim();
			if (isElementPresent(By.xpath("//*[text()='" + name + "']"))) {
				return false;
			}
		}
		return true;
	}

	private void deleteCandidateManualy(String fileNameCsv) throws IOException {
		List<String> fileData = fileReader.getTestData(fileNameCsv);
		for (int i = fileData.size(); i >= 1; i--) {
			pressDelButton(i);
			checkIsLoaded();
		}

	}

	private void pressDelButton(int index) {
		WebElement delBut = webDriver.findElement(By.xpath("//tbody/tr[" + index + "]/td[7]/button"));
		waitForElementToBeInDOM(delBut);
		waitUntilElementToBeClickable(By.xpath("//tbody/tr[" + index + "]/td[7]/button"));
		delBut.click();
	}

	private boolean elementVisibility(String name) {

		return isElementPresent(By.xpath("//*[text()='" + name + "']"));
	}

	private void pressVicinityList(String districtName) {
		WebElement vicinityList = webDriver.findElement(By.xpath("//*[text()='" + districtName + "']/../td[3]/button"));
		vicinityList.click();
	}

	private void pressCandidateList(String districtName) {
		WebElement candidateList = webDriver
				.findElement(By.xpath("//*[text()='" + districtName + "']/../td[4]/button"));
		waitForElementToBeInDOM(candidateList);
		candidateList.click();
	}

	private void pressEditDistrict(String districtName) {
		WebElement buttonEdit = webDriver
				.findElement(By.xpath("//*[text()='" + districtName + "']/../td[5]/button[1]"));
		buttonEdit.click();
	}

	private void pressDeleteDistrict(String districtName) {
		WebElement buttondDel = webDriver
				.findElement(By.xpath("//*[text()='" + districtName + "']/../td[5]/button[2]"));
		buttondDel.click();

	}

	private String getValueFromTableCell(int tableRow, int tableCol) {
		WebElement tableCell = webDriver.findElement(By.xpath("//tbody/tr[" + tableRow + "]/td[" + tableCol + "]"));
		return tableCell.getText();
	}

	private boolean assertCandidateContent(String fileNameCsv) throws IOException {
		List<String> fileData = fileReader.getTestData(fileNameCsv);
		for (int i = 1; i <= fileData.size(); i++) {
			String[] line = fileData.get(i - 1).split(",");
			String name = line[1].replace("\'", "").trim();
			String sure = line[2].replace("\'", "").trim();
			String dateBirth = line[3].trim();
			String allLineFromFile = name + sure + dateBirth;
			String allLineFromUI = getValueFromTableCell(i, 2) + getValueFromTableCell(i, 3)
					+ getValueFromTableCell(i, 4);
			if (!allLineFromFile.equals(allLineFromUI)) {
				return false;
			}
		}
		return true;
	}

	private Set<String> chooseTableMemebers(String fileName, int index) throws IOException {
		List<String> lines = fileReader.getTestData(fileName);
		Set<String> hs = new HashSet<String>();
		for (int i = 0; i < lines.size(); i++) {
			String[] words = lines.get(i).split("\\'|\\ ");
			hs.add(words[index]);
		}
		return hs;
	}

	private Map<String, List<String>> getMapOfDistircitAndVicinities(String fileName) throws IOException {
		Map<String, List<String>> hm = new HashMap<String, List<String>>();
		List<String> fileLines = fileReader.getTestData(fileName);
		for (int index = 0; index < fileLines.size(); index++) {
			String[] words = fileLines.get(index).split("\\'|\\ ");
			if (hm.containsKey(words[0])) {
				continue;
			} else {
				hm.put(words[0], getListForThisDistrict(fileLines, words[0]));
			}
		}
		return hm;
	}

	private List<String> getListForThisDistrict(List<String> fileLines, String districtName) {
		List<String> vicinities = new ArrayList<String>();
		for (String line : fileLines) {
			String[] words = line.split("\\'|\\ ");
			if (words[0].equals(districtName)) {
				vicinities.add(words[1]);
			}
		}
		return vicinities;
	}
}
