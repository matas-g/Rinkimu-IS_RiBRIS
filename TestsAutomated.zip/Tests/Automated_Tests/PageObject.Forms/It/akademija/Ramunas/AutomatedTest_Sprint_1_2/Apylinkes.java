package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Apylinkes extends PageObject {

	// ============Buttons====================
	@FindBy(xpath = "//a[contains(text(), 'Pridėti apylinkę')]")
	@CacheLookup
	private WebElement buttonRegisterV;
	@FindBy(xpath = "//button[contains(text(), 'Registruoti')]")
	@CacheLookup
	private WebElement buttonRegister;
	@FindBy(xpath = "//form/button[1]")
	@CacheLookup
	private WebElement buttonRegisterR;
	@FindBy(xpath = "//button[contains(text(), 'Redaguoti')]")
	@CacheLookup
	private WebElement buttonEdit;
	@FindBy(xpath = "//button[contains(text(), 'Patvirtinti')]")
	@CacheLookup
	private WebElement confDel;
	@FindBy(xpath = "//button[contains(text(), 'Atšaukti')]")
	@CacheLookup
	private WebElement buttonCancel;
	@FindBy(xpath = "//form/button[2]")
	@CacheLookup
	private WebElement buttonCancelR;
	@FindBy(xpath = "//a[contains(text(), 'Pridėti')]")
	@CacheLookup
	private WebElement buttonAddRepresentive;
	@FindBy(xpath = "//button[contains(text(), 'Priskirti')]")
	@CacheLookup
	private WebElement buttonRegisterRepr;

	// ========================================
	// ============Fields======================
	@FindBy(id = "pavadinimas")
	@CacheLookup
	private WebElement fieldName;
	@FindBy(id = "adresas")
	@CacheLookup
	private WebElement fieldAdress;
	@FindBy(id = "skaicius")
	@CacheLookup
	private WebElement fieldPeople;
	@FindBy(xpath = "//form/div[1]//input")
	@CacheLookup
	private WebElement repName;
	@FindBy(xpath = "//form/div[2]//input")
	@CacheLookup
	private WebElement repSure;
	// ========================================
	// ============Selects======================
	@FindBy(xpath = "//select")
	@CacheLookup
	private WebElement dropDistricts;
	@FindBy(css = ".modal-content")
	@CacheLookup
	private WebElement confirmWind;

	// =========================================
	private String vicinity = "";
	private String changeNameTo="";
	private String representativeName = "";
	private String representativeSure = "";
	private String fName = "";
	private String fAdress="";
	private String fPeople="";
	private String district="";
	private FileReader fileReader = new FileReader();
	//=================================================
	public Apylinkes(WebDriver webDriver, String baseUrl) {
		super(webDriver, baseUrl);

	}

	public void assertVicinityRegister(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		buttonRegisterV.click();
		fName = words[1];
		fAdress = words[2];
		fPeople = words[3];
		district = words[0];
		setTextFieldValue(fieldName, fName);
		setTextFieldValue(fieldAdress, fAdress);
		setTextFieldValue(fieldPeople, fPeople);
		selectFromDropDown(dropDistricts, district);
		buttonRegister.click();
		Assert.assertTrue(elementVisibilityInTable(fName), "Didnt register vicinity");
	}
	

	public void assertAddRepresentive(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		vicinity = words[1];
		representativeName = words[5];
		representativeSure = words[6];
		pressAddRepresentative(vicinity);
		setTextFieldValueWithClear(repName, representativeName);
		setTextFieldValueWithClear(repSure, representativeSure);
		buttonRegisterRepr.click();
		Assert.assertTrue(elementVisibilityInTable(representativeName), "Didnt register representor");
		Assert.assertTrue(elementVisibilityInTable(representativeSure), "Didnt register representor");

	}

	public void assertDeleteVicinity(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		vicinity = words[1];
		pressDeleteVicinity(vicinity);
		waitForElementToBeInDOM(confirmWind);
		confDel.click();
		checkIsLoaded();
		waitForElementToBeInDOM(buttonRegisterV);
		webDriver.navigate().refresh();
		checkIsLoaded();
		Assert.assertFalse(elementVisibilityInTable(vicinity), "Didnt delete vicinity");
	}

	public void assertEditVicinity(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		vicinity = words[1];
		fName = words[1];
		fAdress = words[2];
		fPeople = words[3];
		district = words[0];
		changeNameTo = words[4];
		pressEditVicinity(vicinity);
		setTextFieldValueWithClear(fieldName, changeNameTo);
		setTextFieldValueWithClear(fieldAdress, fAdress);
		setTextFieldValueWithClear(fieldPeople, fPeople);
		selectFromDropDown(dropDistricts,district );
		buttonEdit.click();
		Assert.assertFalse(elementVisibilityInTable(vicinity), "Didnt edit vicinity");
		Assert.assertTrue(elementVisibilityInTable(changeNameTo), "Didnt edit vicinity");
	}	

	public void assertCancel(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);
		vicinity = words[1];
		changeNameTo = words[4];
		pressEditVicinity(vicinity);
		setTextFieldValueWithClear(fieldName,changeNameTo );
		buttonCancel.click();
		checkIsLoaded();
		Assert.assertTrue(elementVisibilityInTable(vicinity), "Dont work  correctly");
	}
	public void assertCancelConfirm(String fileName) throws IOException {
		String[] words = fileReader.get1LinesWords(fileName);	
		vicinity = words[1];
		pressDeleteVicinity(vicinity);
		waitForElementToBeInDOM(confirmWind);
		buttonCancel.click();
		checkIsLoaded();
		Assert.assertTrue(elementVisibilityInTable(vicinity), "Dont work  correctly");
	}
	public void assertFieldsValidation(String fileName) throws IOException{
		List<String> fileLines = fileReader.getTestData(fileName);
		System.out.println(fileLines.size());
		for(String line : fileLines){	
			String[] words = line.split("\\'|\\ ");
			String vicinityName = words[1];
			RegisterVicinity(words);					
			Assert.assertFalse(elementVisibilityInTable(vicinityName), "Uzregistruota neleistinai apylinke su neleistinais simboliais: " + vicinityName);
			checkIsLoaded();
		}
	}
	private void RegisterVicinity(String[] words) {
		buttonRegisterV.click();
		fName = words[1];
		fAdress = words[2];
		fPeople = words[3];
		WebElement fNameElement = webDriver.findElement(By.xpath("//*[@id='pavadinimas']"));
		WebElement fAdressElement = webDriver.findElement(By.xpath("//*[@id='adresas']"));
		WebElement fPeopleElement = webDriver.findElement(By.xpath("//*[@id='skaicius']"));
		setTextFieldValueWithClear(fNameElement, fName);
		setTextFieldValueWithClear(fAdressElement, fAdress);
		setTextFieldValueWithClear(fPeopleElement, fPeople);
		WebElement butReg = webDriver.findElement(By.xpath("//button[contains(text(), 'Registruoti')]"));
		butReg.click();
		checkIsLoaded();
	}

	private boolean elementVisibilityInTable(String name) {

		return isElementPresent(By.xpath("//*[text()='" + name + "']"));
	}

	private void pressEditVicinity(String vicinityName) {
		WebElement buttonEdit = webDriver
				.findElement(By.xpath("//*[text()='" + vicinityName + "']/../td[7]/button[1]"));
		buttonEdit.click();
	}

	private void pressDeleteVicinity(String vicinityName) {
		WebElement buttondDel = webDriver
				.findElement(By.xpath("//*[text()='" + vicinityName + "']/../td[7]/button[2]"));
		buttondDel.click();
	}

	private void pressAddRepresentative(String vicinityName) {
		WebElement addRep = webDriver.findElement(By.xpath("//*[text()='" + vicinityName + "']/../td[6]/a"));
		addRep.click();
	}
}
