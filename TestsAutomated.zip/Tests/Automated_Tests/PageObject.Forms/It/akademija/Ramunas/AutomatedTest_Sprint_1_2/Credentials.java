package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import org.openqa.selenium.WebDriver;

public class Credentials {
	
	public static final String pageURL = "http://www.metasite.net";
    public static final String pageUsr = "admin";
    public static final String pagePsw = "12345";
    public static final String accountUsr = "admin@metasite.net";
    public static final String accountPsw = "12345";
}
