package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Partijos extends PageObject {

	public Partijos(WebDriver webDriver, String baseUrl) {
		super(webDriver, baseUrl);

	}

	// ============Buttons====================
	@FindBy(xpath = "//a[contains(text(), 'Pridėti partiją')]")
	@CacheLookup
	private WebElement buttonAdd;

	@FindBy(xpath = "//button[contains(text(), 'Registruoti')]")
	@CacheLookup
	private WebElement buttonRegister;

	@FindBy(xpath = "//button[contains(text(), 'Atšaukti')]")
	@CacheLookup
	private WebElement buttonCancel;
	@FindBy(xpath = "//button[contains(text(), 'Redaguoti')]")
	@CacheLookup
	private WebElement buttonEdit;
	@FindBy(xpath = "//button[contains(text(), 'Patvirtinti')]")
	@CacheLookup
	private WebElement confDel;
	@FindBy(xpath = "//button[contains(text(), 'Pašalinti kandidatus')]")
	@CacheLookup
	private WebElement delList;
	@FindBy(xpath = "//input[@type='file']")
	@CacheLookup
	private WebElement buttonAddList;
	
	// =========================================
	// ============Fields======================
	@FindBy(id = "pavadinimas")
	@CacheLookup
	private WebElement fieldName;
	@FindBy(id = "adresas")
	@CacheLookup
	private WebElement fieldPartyNumb;
	@FindBy(css = ".modal-content")
	@CacheLookup
	private WebElement confirmWind;

	// =========================================
	private String partyName ="";
	private String partyNumb = "";
	private String nameToChange="";
	private FileReader fileReader = new FileReader();
	//=================================================
	public void assertPartyRegister(String fileName) throws IOException, InterruptedException {
		String[] words = fileReader.get1LinesWords(fileName);
		partyName = words[0];
		partyNumb = words[1];
		buttonAdd.click();
		setTextFieldValue(fieldName, partyName);
		setTextFieldValue(fieldPartyNumb, partyNumb);
		buttonRegister.click();
		checkIsLoaded();
		Assert.assertTrue(elementVisibilityInTable(partyName), "Didnt register party");
	}
	
	public void assertCandidateListButton(String fileName) throws IOException{
		String[] words = fileReader.get1LinesWords(fileName);
		partyName = words[0];
		pressCandidateList(partyName);
		checkIsLoaded();
		Assert.assertTrue(isElementPresent(By.xpath("//*[contains(text(),'Kandidatų sąrašas')]")),"Didnt go to page candidate list");
	}
	public void assertDeleteParty(String fileName) throws IOException, InterruptedException {
		String[] words = fileReader.get1LinesWords(fileName);
		partyName = words[0];
		pressDeleteParty(partyName);
		waitForElementToBeInDOM(confirmWind);
		confDel.click();
		//webDriver.navigate().refresh();
		checkIsLoaded();		
		Assert.assertFalse(elementVisibilityInTable(partyName), "Didnt delete party");
	}
	
	public void assertPartyEditor(String fileName) throws IOException, InterruptedException {
		String[] words = fileReader.get1LinesWords(fileName);
		partyName = words[0];
		partyNumb = words[1];
		nameToChange = words[2];
		pressEditParty(partyName);
		setTextFieldValueWithClear(fieldName, nameToChange);
		setTextFieldValueWithClear(fieldPartyNumb, partyNumb);
		buttonEdit.click();
		checkIsLoaded();
		Assert.assertFalse(elementVisibilityInTable(partyName), "Didnt edit, but created new");
		Assert.assertTrue(elementVisibilityInTable(nameToChange), "Didnt edit");
	}
	
	public void assertCancel(String fileName) throws IOException, InterruptedException{
		String[] words = fileReader.get1LinesWords(fileName);
		partyName = words[0];
		nameToChange = words[2];
		pressEditParty(partyName);
		setTextFieldValueWithClear(fieldName, nameToChange);
		buttonCancel.click();
		checkIsLoaded();
		Assert.assertFalse(elementVisibilityInTable(nameToChange), "Didnt cancel, but created new");
		Assert.assertTrue(elementVisibilityInTable(partyName), "Party name has been changed");
	}
	public void assertPartyList(String fileNameForTest, String fileNameCsv) throws IOException {
		String[] words = fileReader.get1LinesWords(fileNameForTest);	
		partyName = words[0];
		partyNumb = words[1];
		buttonAdd.click();
		setTextFieldValue(fieldName, partyName);
		setTextFieldValue(fieldPartyNumb, partyNumb);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		checkIsLoaded();				
		pressCandidateList(partyName);
		checkIsLoaded();
		assertCandidateContent(fileNameCsv);
	}
	public void assertPartyListDelete(String fileNameForTest, String fileNameCsv) throws IOException {
		String[] words = fileReader.get1LinesWords(fileNameForTest);	
		partyName = words[0];
		partyNumb = words[1];
		buttonAdd.click();
		setTextFieldValue(fieldName, partyName);
		setTextFieldValue(fieldPartyNumb, partyNumb);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		checkIsLoaded();		
		pressEditParty(partyName);
		delList.click();
		buttonEdit.click();
		pressCandidateList(partyName);
		checkIsLoaded();	
		Assert.assertFalse(isElementPresent(By.xpath("//tbody/tr[1]")),"Sarasas nepasalintas");
		//assertCandidateListDeletion(fileNameCsv);
	}
	public void assertPartyCandidateDeletionButton(String fileNameForTest, String fileNameCsv) throws IOException {
		String[] words = fileReader.get1LinesWords(fileNameForTest);	
		partyName = words[0];
		partyNumb = words[1];
		buttonAdd.click();
		setTextFieldValue(fieldName, partyName);
		setTextFieldValue(fieldPartyNumb, partyNumb);
		buttonAddList.sendKeys(fileNameCsv);
		buttonRegister.click();
		checkIsLoaded();			
		pressCandidateList(partyName);
		checkIsLoaded();
		deleteCandidateManualy(fileNameCsv);
		assertCandidateListDeletion(fileNameCsv);
	}
	private void deleteCandidateManualy(String fileNameCsv) throws IOException {		
		List<String> fileData = fileReader.getTestData(fileNameCsv);		
		for (int i = fileData.size(); i >= 1; i--) {				
			pressDelButton(i);
			checkIsLoaded();
		}
		
	}

	private void pressDelButton(int index) {
		WebElement delBut = webDriver.findElement(By.xpath("//tbody/tr[" + index + "]/td[7]/button"));
		waitForElementToBeInDOM(delBut);
		waitUntilElementToBeClickable(By.xpath("//tbody/tr[" + index + "]/td[7]/button"));
		delBut.click();
	}

	private String getValueFromTableCell(int tableRow, int tableCol) {
		WebElement tableCell = webDriver.findElement(By.xpath("//tbody/tr[" + tableRow + "]/td[" + tableCol + "]"));
		return tableCell.getText();
	}
	private void assertCandidateContent(String fileNameCsv) throws IOException {
		List<String> fileData = fileReader.getTestData(fileNameCsv);
		for (int i = 1; i <= fileData.size(); i++) {
			String[] line = fileData.get(i - 1).split(",");
			String name = line[1].replace("\'", "").trim();
			String sure = line[2].replace("\'", "").trim();
			String dateBirth = line[3].trim();
			String allLineFromFile = name + sure + dateBirth;
			String allLineFromUI = getValueFromTableCell(i, 2) + getValueFromTableCell(i, 3)
					+ getValueFromTableCell(i, 4);
			Assert.assertEquals(allLineFromFile, allLineFromUI, "irasas neatitinka");
		}
	}
	private void assertCandidateListDeletion(String fileNameCsv) throws IOException {
		List<String> fileData = fileReader.getTestData(fileNameCsv);
		for (int i = 1; i <= fileData.size(); i++) {
			String[] line = fileData.get(i - 1).split(",");
			String name = line[1].replace("\'", "").trim();
			String sure = line[2].replace("\'", "").trim();
			String dateBirth = line[3].trim();			
			Assert.assertFalse(isElementPresent(By.xpath("//*[text()='" + name + "']")),"Nepasalintas kandidatas" + name);
		}
	}
	private void pressCandidateList(String partyName) {
		WebElement candidateList = webDriver
				.findElement(By.xpath("//*[text()='" + partyName + "']/../td[4]/button"));
		candidateList.click();
	}
	private void pressEditParty(String partyName) {		
		WebElement buttonEdit = webDriver.findElement(By.xpath("//*[text()='"+partyName+"']/../td[5]/button[1]"));
		buttonEdit.click();
	}

	private void pressDeleteParty(String partyName) {		
		WebElement buttondDel = webDriver.findElement(By.xpath("//*[text()='"+partyName+"']/../td[5]/button[2]"));
		buttondDel.click();
		checkIsLoaded();
	}
	private boolean elementVisibilityInTable(String name) throws InterruptedException {
		Thread.sleep(1000); //Call hans... 0 freaking wait methods helped...
		checkIsLoaded();
		return isElementPresent(By.xpath("//*[text()='" + name + "']"));
	}
	
}
