package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class HomePage extends PageObject {
	
	@FindBy(xpath = "//a[contains(@href, '#/login')]")
	@CacheLookup
	private WebElement elementByFunctionlogin;
	@FindBy(xpath = "//a[contains(@href, '#/admin')]")
	@CacheLookup
	private WebElement elementByFunctionAdministratoriui;
	@FindBy(xpath = "//a[contains(text(), 'Apygardos')]")
	@CacheLookup
	private WebElement elementByFunctionApygarda;
	@FindBy(xpath = "//a[contains(text(), 'Apylinkes')]")
	@CacheLookup
	private WebElement elementByFunctionApylinke;
	@FindBy(xpath = "//a[contains(text(), 'Atstovai')]")
	@CacheLookup
	private WebElement elementByFunctionAtstovai;
	@FindBy(xpath = "//a[contains(text(), 'Partijos')]")
	@CacheLookup
	private WebElement elementByFunctionPartijos;
	// --- find an element which is always visible and clickable in a page ---
	// --- should be better if it's loaded one of the latest ---
	private String elementForWaiting = "//a/b[text() = 'Apylinkes']";

	// --- another wait is for an element which should disappear (example:
	// successful deletion message) ---
	//private String elementForWaitingToBeGone = "//div[@ng-reflect-inner-h-t-m-l='Selection successfully removed.']";

	public HomePage(WebDriver webDriver, String baseUrl) {
		super(webDriver, baseUrl);

	}

	public void checkIsLoaded() {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(webDriver, 30);
		wait.until(pageLoadCondition);

		// --- use "elementForWaiting" element for double checking if the page
		// is completed loaded
		// --- if there is no need for double checking - just remove below line
		// (most of the time it's enough to have above single check)
//		try {
//			waitUntilElementToBeClickable(By.xpath(elementForWaiting));
//		} catch (Exception e) {
//			Assert.fail("Could not wait while page will completely load");
//		}
	}

	/**
	 * Waits till green completion message dissapears
	 */
	// public void checkDeletionMsgDisappeared() {
	// try {
	// //WebDriverWait wait = new WebDriverWait(webDriver, 60);
	// ExpectedConditions.invisibilityOfElementLocated(By.xpath(elementForWaitingToBeGone));
	// } catch (Exception e) {
	// Assert.fail("Could not wait while element will not be visible");
	// }
	// }

	// ==================================================================================================================
	// --- getters
	// ------------------------------------------------------------------------------------------------------
	// ==================================================================================================================

	/**
	 * Most common and simplest example of getter: returns tag's text
	 * 
	 * @return
	 */
	// public String getUsername() { return getTextFieldValue(elementByName); }
	//
	// /**
	// * Returns "prefix" attribute's value for "elementByName" element
	// * @return
	// */
	// public String getCountryPrefix() {
	// return getFieldAttributeValue(elementByName, "prefix");
	// }

	/**
	 * Returns given element's parent tag
	 * 
	 * @param element
	 * @return
	 */
	public WebElement getParentWebElement(WebElement element) {
		return element.findElement(By.xpath(".."));
	}

	/**
	 * Returns given element's ONE child tag
	 * 
	 * @param element
	 * @param childsXpath
	 * @return
	 */
	public WebElement getChildWebElement(WebElement element, String childsXpath) {
		return element.findElement(By.xpath(".//" + childsXpath));
	}

	// ==================================================================================================================
	// --- setters
	// ------------------------------------------------------------------------------------------------------
	// ==================================================================================================================

	/**
	 * Most common and simplest of setter: enter string into text field All
	 * elements should be interacted only through functions - not directly from
	 * the test
	 * 
	 * @param value
	 */
	// public void setUsername(String value) {
	// //--- unhide element: take attribute from the element and change it to
	// whatever you need ---
	// String js = "arguments[0].style.display='inline';";
	// ((JavascriptExecutor) webDriver).executeScript(js, elementByXpath);
	//
	// waitForElementToBeInDOM(elementByName);
	// setTextFieldValue(elementByName, value);
	// }

	// ==================================================================================================================
	// --- buttons
	// ------------------------------------------------------------------------------------------------------
	// ==================================================================================================================

	/**
	 * Clicks search button and returnds Google Search results page
	 */
	public Apygarda openApygarda() {
		System.out.println("Opening 'Login' button...");
		waitForElementToBeInDOM(elementByFunctionlogin);
		elementByFunctionlogin.click();
		System.out.println("Opening 'Administratoriui' button...");
		waitForElementToBeInDOM(elementByFunctionAdministratoriui);
		elementByFunctionAdministratoriui.click();
		
		System.out.println("Opening 'Apygarda' button...");
		waitForElementToBeInDOM(elementByFunctionApygarda);
		elementByFunctionApygarda.click();
		return new Apygarda(webDriver, baseUrl);
	}
	public Apylinkes openApylinke() {
		System.out.println("Opening 'Login' button...");
		waitForElementToBeInDOM(elementByFunctionlogin);
		elementByFunctionlogin.click();
		System.out.println("Opening 'Administratoriui' button...");
		waitForElementToBeInDOM(elementByFunctionAdministratoriui);
		elementByFunctionAdministratoriui.click();
		
		System.out.println("Opening 'Apylinkes' button...");
		waitForElementToBeInDOM(elementByFunctionApylinke);
		elementByFunctionApylinke.click();
		return new Apylinkes(webDriver, baseUrl);
	}	
	public Atstovai openAtstovai() {
		System.out.println("Opening 'Login' button...");
		waitForElementToBeInDOM(elementByFunctionlogin);
		elementByFunctionlogin.click();
		System.out.println("Opening 'Administratoriui' button...");
		waitForElementToBeInDOM(elementByFunctionAdministratoriui);
		elementByFunctionAdministratoriui.click();
		
		System.out.println("Opening 'Atstovai' button...");
		waitForElementToBeInDOM(elementByFunctionAtstovai);
		elementByFunctionAtstovai.click();
		return new Atstovai(webDriver, baseUrl);
	}
	public Partijos openPartijos() {
		System.out.println("Opening 'Login' button...");
		waitForElementToBeInDOM(elementByFunctionlogin);
		elementByFunctionlogin.click();
		System.out.println("Opening 'Administratoriui' button...");
		waitForElementToBeInDOM(elementByFunctionAdministratoriui);
		elementByFunctionAdministratoriui.click();
		
		System.out.println("Opening 'Partijos' button...");
		waitForElementToBeInDOM(elementByFunctionPartijos);
		elementByFunctionPartijos.click();
		return new Partijos(webDriver, baseUrl);
	}

	// ==================================================================================================================
	// --- asserts
	// ------------------------------------------------------------------------------------------------------
	// ==================================================================================================================

	/**
	 * Asserts if "elementByCss" elements holds "New client" text Asserts should
	 * only be used in assert... functions like this - don't add them in
	 * setters, getters or regular functions
	 */
	// public void assertTitle(String value) {
	// System.out.println("Asserting '" + value + "' title...");
	//
	// waitForElementToBeInDOM(elementByCss);
	// Assert.assertEquals(elementByCss.getText(), value, "Title");
	// }
	//
	// public void assertLogoIsDisplayed() {
	// System.out.println("Asserting if logo is displayed...");
	//
	// Assert.assertTrue(isElementDisplayed(elementByCss), "Logo is not
	// displayed!");
	// }
}
