package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.Test;

public class Apylinkes_Tests extends TestMain {
	private String url = "http://localhost:8080";

	@Test(priority = 1)
	public void registerVicinity() throws IOException {
		DB.insertDistrict(Constants.fileDistrict1);
		// --- login --
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();
		// --- open Apygarda page ---
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();

		districtPage.assertVicinityRegister(Constants.fileVicinity1);
	}

	@Test(priority = 2)
	public void registerRepres() throws IOException {
		try {
			DB.insertVicinity(Constants.fileVicinity1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();
		// --- open Apygarda page ---
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();

		districtPage.assertAddRepresentive(Constants.fileVicinity1);
	}

	@Test(priority = 3)
	public void editVicinity() throws SQLException, IOException {
		DB.insertVicinity(Constants.fileVicinity1);
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		webDriver.navigate().refresh();
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();
		districtPage.assertEditVicinity(Constants.fileVicinity1);
	}
	@Test(priority = 4)
	public void assertCancel() throws SQLException, IOException {
		DB.insertVicinity(Constants.fileVicinity1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();

		// --- open Apygarda page ---
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();
		districtPage.assertCancel(Constants.fileVicinity1);
	}
	@Test(priority = 5)
	public void assertCancelConf() throws SQLException, IOException {
		DB.insertVicinity(Constants.fileVicinity1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();

		// --- open Apygarda page ---
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();
		districtPage.assertCancelConfirm(Constants.fileVicinity1);
	}
	@Test(priority = 6)
	public void deleteVicinity() throws SQLException, IOException{
		DB.insertVicinity(Constants.fileVicinity1);
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		webDriver.navigate().refresh();
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();
		districtPage.assertDeleteVicinity(Constants.fileVicinity1);
	}
	@Test(priority = 7)
	public void vicinityFieldValidation() throws SQLException, IOException{
		DB.insertDistrict(Constants.fileDistrict1);
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		webDriver.navigate().refresh();
		Apylinkes districtPage = homePage.openApylinke();
		districtPage.checkIsLoaded();
		districtPage.assertFieldsValidation(Constants.fileValidateVicinitiesFields);
	}

	
}
