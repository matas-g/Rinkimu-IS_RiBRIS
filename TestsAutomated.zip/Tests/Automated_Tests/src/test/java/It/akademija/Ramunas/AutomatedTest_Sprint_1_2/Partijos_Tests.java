package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.Test;

public class Partijos_Tests extends TestMain {
	@Test(priority = 1)
	public void registerParty() throws IOException, InterruptedException {
		try {
			// --- login --
			HomePage homePage = loginAdmin(webDriver);
			homePage.checkIsLoaded();
			webDriver.navigate().refresh();
			// --- open Apygarda page ---
			Partijos districtPage = homePage.openPartijos();
			districtPage.checkIsLoaded();
			districtPage.assertPartyRegister(Constants.fileParty1);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority = 2)
	public void assertCandidateListButton() throws IOException {
		DB.insertParty(Constants.fileParty1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();
		// --- open Apygarda page ---
		Partijos districtPage = homePage.openPartijos();
		districtPage.checkIsLoaded();
		districtPage.assertCandidateListButton(Constants.fileParty1);

	}

	@Test(priority = 3)
	public void editParty() throws SQLException, IOException, InterruptedException {
		DB.insertParty(Constants.fileParty1);
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		webDriver.navigate().refresh();
		Partijos districtPage = homePage.openPartijos();
		districtPage.checkIsLoaded();
		districtPage.assertPartyEditor(Constants.fileParty1);
	}

	@Test(priority = 4)
	public void cancelEditParty() throws SQLException, IOException, InterruptedException {
		try {
			DB.insertParty(Constants.fileParty1);
			HomePage homePage = loginAdmin(webDriver);
			homePage.checkIsLoaded();
			// --- open Apygarda page ---
			webDriver.navigate().refresh();
			Partijos districtPage = homePage.openPartijos();
			districtPage.checkIsLoaded();
			districtPage.assertCancel(Constants.fileParty1);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority = 5)
	public void assertDeletePartyButton() throws IOException, InterruptedException {
		try {
			DB.insertParty(Constants.fileParty1);
			// --- login ---
			HomePage homePage = loginAdmin(webDriver);
			homePage.checkIsLoaded();
			webDriver.navigate().refresh();
			// --- open Apygarda page ---
			Partijos districtPage = homePage.openPartijos();
			districtPage.checkIsLoaded();
			districtPage.assertDeleteParty(Constants.fileParty1);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority = 6)
	public void assertPartyListContent() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		Partijos districtPage = homePage.openPartijos();
		districtPage.checkIsLoaded();
		districtPage.assertPartyList(Constants.fileParty1, Constants.DarboPartijaCsv);

	}

	@Test(priority = 7)
	public void assertPartyListContentDeletion() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		Partijos districtPage = homePage.openPartijos();
		districtPage.checkIsLoaded();
		districtPage.assertPartyListDelete(Constants.fileParty1, Constants.DarboPartijaCsv);

	}

	@Test(priority = 8)
	public void assertPartyListContentDeletionButton() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		Partijos districtPage = homePage.openPartijos();
		districtPage.checkIsLoaded();
		districtPage.assertPartyCandidateDeletionButton(Constants.fileParty1, Constants.DarboPartijaCsv);

	}
}
