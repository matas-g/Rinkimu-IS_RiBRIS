package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;

import org.testng.annotations.Test;

public class Atstovai_Tests extends TestMain {
	private String url = "http://localhost:8080";

	@Test(priority = 1)
	public void assertEditRepresentative() throws IOException {
		DB.insertRepresantive(Constants.fileVicinity1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Atstovai districtPage = homePage.openAtstovai();
		districtPage.checkIsLoaded();
		districtPage.assertEditRepr(Constants.fileVicinity1);

	}
	@Test(priority = 2)
	public void assertDelRepresentative() throws IOException {
		DB.insertRepresantive(Constants.fileVicinity1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Atstovai districtPage = homePage.openAtstovai();
		districtPage.checkIsLoaded();
		districtPage.assertDelRepr(Constants.fileVicinity1);

	}
}
