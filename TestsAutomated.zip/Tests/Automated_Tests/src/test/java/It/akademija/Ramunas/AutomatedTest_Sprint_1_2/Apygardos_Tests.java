package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

//Uzdejau grazesni logeri extentReports bet sena versija turi daug bugu, tai visu testu nedariau, 
//bet pasimeginau. Graziau atvaizduoja nei deffault testng reportas, bet geriau naudoti naujesnes versijas
public class Apygardos_Tests extends TestMain {

	private String url = "http://localhost:8080";

	@Test(priority = 1)
	public void assertRegisterDistrict() throws IOException {

		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertInputDistrict(Constants.fileDistrict1, Constants.taurageCsv);
	}

	@Test(priority = 2)
	public void assertVicinityListButton() throws IOException {
		DB.insertDistrict(Constants.fileDistrict1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertVicinityListButton(Constants.fileDistrict1);

	}

	@Test(priority = 3)
	public void assertCandidateListButton() throws IOException {
		DB.insertDistrict(Constants.fileDistrict1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();
		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertCandidateListButton(Constants.fileDistrict1);
	}

	@Test(priority = 4)
	public void assertEditDistrict() throws IOException {
		DB.insertDistrict(Constants.fileDistrict1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertEdit(Constants.fileDistrict1);
	}

	@Test(priority = 5)
	public void assertCancel() throws IOException {

		DB.insertDistrict(Constants.fileDistrict1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertCancel(Constants.fileDistrict1);
	}

	@Test(priority = 6)
	public void assertCancelConfirmDistrict() throws IOException {
		DB.insertDistrict(Constants.fileDistrict1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();
		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertCancelConfirm(Constants.fileDistrict1);
	}

	@Test(priority = 7)
	public void assertDeleteDistrict() throws IOException {
		DB.insertDistrict(Constants.fileDistrict1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();
		webDriver.navigate().refresh();
		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertDeleteDistrict(Constants.fileDistrict1);
	}

	@Test(priority = 8)
	public void assertSoloMandateCandidateListContent() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertCandidateList(Constants.fileDistrict1, Constants.taurageCsv);
	}

	@Test(priority = 9)
	public void assertVicinityListContent() throws IOException, SQLException {
		DB.insertVicinity(Constants.fileVicinity1);
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertVicinityList(Constants.fileVicinity1);
	}

	@Test(priority = 10)
	public void assertDistrictNameValidation() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertNameValidation(Constants.fileValidateDistrict);
	}

	@Test(priority = 11)
	public void assertDistrictCandidateDeletionButton() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertDistrictCandidateDeletionButton(Constants.fileDistrict1, Constants.taurageCsv);
	}

	@Test(priority = 12)
	public void assertDistrictCandidatesDeletion() throws IOException {
		// --- login ---
		HomePage homePage = loginAdmin(webDriver);
		homePage.checkIsLoaded();

		// --- open Apygarda page ---
		Apygarda districtPage = homePage.openApygarda();
		districtPage.checkIsLoaded();
		districtPage.assertDistrictListDelete(Constants.fileDistrict1, Constants.taurageCsv);
	}
}
