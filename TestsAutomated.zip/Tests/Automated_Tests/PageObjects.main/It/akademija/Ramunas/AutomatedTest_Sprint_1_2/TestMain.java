package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.relevantcodes.extentreports.ExtentReports;


public abstract class TestMain {
	public WebDriver webDriver;
	public DataBaseFunctions DB = new DataBaseFunctions();	
	

	/**
	 * Initialize webDriver
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void initialize() throws Exception {
		DB.connDataBase();	
		DB.deleteTable("CANDIDATES");
		DB.deleteTable("PARTY_RESULTS_ENTITY");
		DB.deleteTable("PARTIES");
		DB.deleteTable("POLLING_DISTRICT_REPRESENTATIVES");				 
		DB.deleteTable("POLLING_DISTRICTS");
		DB.deleteTable("CONSTITUENCIES");
		webDriver = initWebDriver(webDriver);			
	}

	/**
	 * Closes webDriver
	 * 
	 * @throws Exception
	 */
	@AfterMethod
	public void tearDown() throws Exception {		
		DB.closeDB();
		webDriver.close();
		webDriver.quit();
	}

	/**
	 * Initialize Firefox browser
	 * 
	 * @param webDriver
	 * @return
	 */
	public static WebDriver initWebDriver(WebDriver webDriver) {

		// --- starting Firefox Marionette ---
//		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
//		capabilities.setCapability("marionette", true);
//
//		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		webDriver = new  FirefoxDriver();
		webDriver.get("http://localhost:8080");
		webDriver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
		webDriver.manage().window().maximize();
		//webDriver.navigate().refresh();

		return webDriver;
	}

	/**
	 * Initialize Firefox browser. Not in use anymore
	 * 
	 * @param webDriver
	 * @return
	 */
	public static WebDriver initWebDriverOLD(WebDriver webDriver) {

		// --- setting virtual display ---
		FirefoxBinary ffox = new FirefoxBinary();
		ffox.setEnvironmentProperty("DISPLAY", ":99");

		// -- setting Unexpected behaviour ---
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
		dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);

		// --- load pages faster ---
		FirefoxProfile fp = new FirefoxProfile();
		fp.setPreference("webdriver.load.strategy", "unstable");
		fp.setPreference("extensions.checkCompatibility", false);

		// --- starting Firefox OLD ---
		webDriver = new FirefoxDriver(ffox, fp, dc);
		webDriver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
		webDriver.manage().window().maximize();

		return webDriver;
	}
	
	/**
     * Logins to page and returns First default page
     * @param webDriver
     * @return
     */
    public HomePage loginAdmin(WebDriver webDriver) {

        //--- open page with credentials in URL ------------------------------------------------------------------------
        //LoginPage loginPage = new LoginPage(webDriver, "https://" +
        //        Credentials.pageUsr + ":" +
        //        Credentials.pagePsw + "@" +
        //        Credentials.pageURL, true);
        //loginPage.checkIsLoaded();
        
        //--- open page without credentials in URL ---------------------------------------------------------------------
       // LoginPage loginPage = new LoginPage(webDriver, Credentials.pageURL, true);
       // loginPage.checkIsLoaded();

        //--- fill login form for session credentials (if no login form requested, skip it -----------------------------
//        if(loginPage.isLoginRequired()) {
//            loginPage.enterUsername(Credentials.accountUsr);
//            loginPage.enterPassword(Credentials.accountPsw);
//            homePage = loginPage.clickLogin();
//        } else {
//        	homePage = loginPage.returnHomePage();
//        }

        return new HomePage(webDriver,"http://localhost:8080");
    }
    public HomePage loginRepresantive(WebDriver webDriver) {

        //--- open page with credentials in URL ------------------------------------------------------------------------
        //LoginPage loginPage = new LoginPage(webDriver, "https://" +
        //        Credentials.pageUsr + ":" +
        //        Credentials.pagePsw + "@" +
        //        Credentials.pageURL, true);
        //loginPage.checkIsLoaded();
        
        //--- open page without credentials in URL ---------------------------------------------------------------------
       // LoginPage loginPage = new LoginPage(webDriver, Credentials.pageURL, true);
       // loginPage.checkIsLoaded();

        //--- fill login form for session credentials (if no login form requested, skip it -----------------------------
//        if(loginPage.isLoginRequired()) {
//            loginPage.enterUsername(Credentials.accountUsr);
//            loginPage.enterPassword(Credentials.accountPsw);
//            homePage = loginPage.clickLogin();
//        } else {
//        	homePage = loginPage.returnHomePage();
//        }

        return new HomePage(webDriver,"http://localhost:8080");
    }
    public HomePage noLogin(WebDriver webDriver) {

        //--- open page with credentials in URL ------------------------------------------------------------------------
        //LoginPage loginPage = new LoginPage(webDriver, "https://" +
        //        Credentials.pageUsr + ":" +
        //        Credentials.pagePsw + "@" +
        //        Credentials.pageURL, true);
        //loginPage.checkIsLoaded();
        
        //--- open page without credentials in URL ---------------------------------------------------------------------
       // LoginPage loginPage = new LoginPage(webDriver, Credentials.pageURL, true);
       // loginPage.checkIsLoaded();

        //--- fill login form for session credentials (if no login form requested, skip it -----------------------------
//        if(loginPage.isLoginRequired()) {
//            loginPage.enterUsername(Credentials.accountUsr);
//            loginPage.enterPassword(Credentials.accountPsw);
//            homePage = loginPage.clickLogin();
//        } else {
//        	homePage = loginPage.returnHomePage();
//        }

        return new HomePage(webDriver,"http://localhost:8080");
    }
}