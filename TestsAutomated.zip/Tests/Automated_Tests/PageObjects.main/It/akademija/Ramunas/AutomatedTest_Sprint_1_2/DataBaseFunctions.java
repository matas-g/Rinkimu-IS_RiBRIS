package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DataBaseFunctions {
	private Connection conn = null;
	private Statement stmt = null;
	private String url = "jdbc:h2:C://Users//Romarijo//Desktop//DB//database-dev;MV_STORE=true;AUTO_SERVER=TRUE;IFEXISTS=TRUE";
	private String user = "sa";
	private String pass = "";
	private final String JDBC_DRIVER = "org.h2.Driver";
	private FileReader fileReader = new FileReader();

	public void connDataBase() {
		try {
			Class.forName(JDBC_DRIVER);
			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(url, user, pass);
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void insertDistrict(String fileName) throws IOException {
		try {
			Set<String> districtSet = chooseTableMemebers(fileName, 0);
			
//			Set<String> hs = new HashSet<String>();
//			hs.addAll(lines);
//			lines.clear();
//			lines.addAll(hs);
			for (String district : districtSet) {
				stmt = conn.createStatement();
				String insertQuery = "INSERT INTO CONSTITUENCIES (CONSTITUENCY_NAME ) VALUES('" + district + "');";
				stmt.execute(insertQuery);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void insertParty(String fileName) throws IOException {
		try {
			String[] words = fileReader.get1LinesWords(fileName);
			stmt = conn.createStatement();
			String insertQuery = "INSERT INTO PARTIES  (NAME,PARTY_NUMBER ) VALUES('" + words[0] + "',"
					+ Integer.parseInt(words[1]) + ");";
			stmt.execute(insertQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteTable(String name) {
		try {
			stmt = conn.createStatement();
			String deleteTableQuery = "DELETE FROM " + name;
			stmt.execute(deleteTableQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void insertVicinity(String fileName) throws SQLException, IOException {

		try {
			insertDistrict(fileName);
			List<String> lines = fileReader.getTestData(fileName);
			for (int i = 0; i < lines.size(); i++) {
				String[] words = lines.get(i).split(" ");
				stmt = conn.createStatement();
				String insertQuery = "INSERT INTO POLLING_DISTRICTS(ADDRESS,POLLING_DISTRICT_NAME,NUMBER_OF_VOTERS,CONSTITUENCY_ID) VALUES('"
						+ words[2] + "','" + words[1] + "'," + words[3] + "," + getId("CONSTITUENCIES", words[0]) + ")";
				stmt.execute(insertQuery);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void insertRepresantive(String fileName) throws IOException {
		try {
			insertVicinity(fileName);
			String[] words = fileReader.get1LinesWords(fileName);
			stmt = conn.createStatement();
			String insertQuery = "INSERT INTO POLLING_DISTRICT_REPRESENTATIVES (NAME ,SURNAME ,POLLING_DISTRICT_ID ) VALUES('"
					+ words[5] + "','" + words[6] + "'," + getId("POLLING_DISTRICTS", words[1]) + ")";
			stmt.execute(insertQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void closeDB() {
		try {
			System.out.println("Closing Data base");
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private int getId(String tableName, String Name) throws SQLException {
		String query = "";
		if (tableName.equals("CONSTITUENCIES")) {
			query = "SELECT ID FROM CONSTITUENCIES WHERE CONSTITUENCY_NAME =?";
		} else if (tableName.equals("POLLING_DISTRICTS")) {
			query = "SELECT ID FROM POLLING_DISTRICTS WHERE POLLING_DISTRICT_NAME =?";
		}
		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setString(1, Name);
		ResultSet res = stmt.executeQuery();
		res.next();
		return res.getInt(1);
	}
	private Set<String> chooseTableMemebers(String fileName, int index) throws IOException{
		List<String> lines = fileReader.getTestData(fileName);
		Set<String> hs = new HashSet<String>();
		for (int i = 0; i < lines.size(); i++){
			String[] words = lines.get(i).split("\\'|\\ ");
			hs.add(words[index]);
		}
		return hs;
	}
}
