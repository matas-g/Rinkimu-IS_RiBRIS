package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

public class Constants {
//	public static final String fileDistrict1 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\district.txt";
//	public static final String fileDistrict2 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\district2.txt";
//	public static final String fileValidateDistrict = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\validateDistrictsNames.txt";
//	public static final String fileVicinity1 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\vicinity.txt";
//	public static final String fileValidateVicinitiesFields = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\validateVicinityFields.txt";
//	public static final String fileVicinity2 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\vicinity2.txt";
//	public static final String fileVicinity3 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\vicinity3.txt";
//	public static final String fileParty1 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\party.txt";
//	public static final String fileRepresentive1 = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\representive.txt";
//	public static final String kaunasCsv = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\kandidatai-kaunas.csv";
//	public static final String vilniusCsv = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\kandidatai-vilnius.csv";
//	public static final String taurageCsv = "C:\\Users\\ZP16_1\\Desktop\\RAlksnys_Stuff\\test_files\\kandidatai-taurage.csv";
//	public static final String saveResults = "C:\\Users\\Romarijo\\Desktop\\Tests\\advanceReport.html";
	public static final String saveResults = System.getProperty("user.home") + "\\Desktop\\Tests\\advanceReport3.html";
	public static final String taurageCsv = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\kandidatai-taurage.csv";
	public static final String DarboPartijaCsv = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\kandidataiPartijai.csv";
	public static final String fileDistrict1 = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\district.txt";
	public static final String fileVicinity1 = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\vicinity.txt";
	public static final String fileValidateVicinitiesFields = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\validateVicinityFields.txt";
	public static final String fileValidateDistrict = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\validateDistrictsNames.txt";
	public static final String fileParty1 = System.getProperty("user.home") + "\\Desktop\\Tests\\test_files\\party.txt";
}
