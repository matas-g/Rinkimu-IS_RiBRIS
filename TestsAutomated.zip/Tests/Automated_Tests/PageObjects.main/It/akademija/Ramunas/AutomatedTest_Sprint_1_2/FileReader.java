package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;

import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FileReader {
	private List<String> records = new ArrayList();
	public List<String> getTestData(String fileName) throws IOException {
		records = Files.readAllLines(Paths.get(fileName));		
		return records;
	}
	public String[] get1LinesWords(String fileName) throws IOException{
		return getTestData(fileName).get(0).split(" ");		
	}
}
