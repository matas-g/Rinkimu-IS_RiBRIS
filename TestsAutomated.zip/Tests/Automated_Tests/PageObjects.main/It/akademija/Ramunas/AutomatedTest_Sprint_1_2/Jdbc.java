package It.akademija.Ramunas.AutomatedTest_Sprint_1_2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbc {


	   public static void main(String[] args) {

	      Connection conn = null;
	      Statement stmt = null;
	      String url = "jdbc:h2:C://Users//Romarijo//Desktop//DB//database-dev;MV_STORE=true;AUTO_SERVER=TRUE;IFEXISTS=TRUE";

	      String user = "sa";
	      String pass = "";
	      final String JDBC_DRIVER = "org.h2.Driver";

	      try {
	         // STEP 1: Register JDBC driver
	         Class.forName(JDBC_DRIVER);

	         //STEP 2: Open a connection
	         System.out.println("Connecting to database...");
	         conn = DriverManager.getConnection(url, user, pass);

	         //STEP 3: Execute a query
	         System.out.println("Updating database...");
	         //showAccounts(conn);
	         conn.setAutoCommit(false);

	         stmt = conn.createStatement();

	         String updateQuery1 = "INSERT INTO CONSTITUENCIES (CONSTITUENCY_NAME ) VALUES('Kaunas')";
	         stmt.execute(updateQuery1);

	            /*try {
	               String updateQuery2 = "UPDATE accounts SET balance = balance + 10 WHERE AccountNo = 2";
	               stmt.execute(updateQuery2);
	            } catch (SQLException ex) {
	               System.out.println("Rollback");
	               conn.rollback();
	            }*/

	         conn.commit();
	         conn.setAutoCommit(true);

	         //showAccounts(conn);
	         // STEP 4: Clean-up environment
	         stmt.close();
	         conn.close();
	         System.out.println("Finished...");

	      } catch (SQLException ex) {
	         System.out.println(ex.getMessage());
	      } catch (ClassNotFoundException e) {
	         e.printStackTrace();
	      } finally {
	         try {
	            if (stmt != null) stmt.close();
	         } catch (SQLException se2) {
	         }
	         try {
	            if (conn != null) conn.close();
	         } catch (SQLException se) {
	            se.printStackTrace();
	         }
	         System.out.println("Finished...");
	      }
	   }

	      /*private static void showAccounts(Connection conn) throws SQLException {
	         String query = "select * from accounts";
	         PreparedStatement stmt = conn.prepareStatement(query);
	         ResultSet res = stmt.executeQuery();
	         while (res.next()) {
	            System.out.println("AccountNo: " + res.getInt(1) + ", Balance = " + res.getDouble(2));
	         }
	      }*/


	}